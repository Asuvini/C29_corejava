package aaaa.ece;

import java.util.Scanner;

import com.cg.dayeight.abstraction.AbstractDemo;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		AbstractDemo ad = new AbstractDemo();
	}

}
