package aaaa.ece;

public interface InterfaceDemo {

	//protected float area;
	
	//abstract method
	abstract void calArea();
	
	//concrete method
	void show() {
		System.out.println("Area is : "+area);
	}
}
