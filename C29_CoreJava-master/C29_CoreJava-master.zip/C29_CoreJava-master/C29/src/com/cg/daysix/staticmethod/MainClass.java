package com.cg.daysix.staticmethod;

public class MainClass {

	public static void main(String[] args) {
		//MyClass c = new MyClass();
		//c.print();
		
		MyClass.display(6);
		
	}

}
