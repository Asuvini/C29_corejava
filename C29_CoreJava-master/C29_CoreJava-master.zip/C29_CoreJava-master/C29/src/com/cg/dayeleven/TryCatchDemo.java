package com.cg.dayeleven;

public class TryCatchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Inside Main");
		TryCatch tc = new TryCatch();
		tc.divide(20, 2);

	}

}
