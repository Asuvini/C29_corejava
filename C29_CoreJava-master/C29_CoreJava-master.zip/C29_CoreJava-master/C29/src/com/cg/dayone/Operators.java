package com.cg.dayone;

public class Operators {

	public static void main(String[] args) {
		//arithmetic operators
		int a = 5, b = 8;
		float c;
		/*c = a+b;
		System.out.println("C is: "+c);
		c = a-b;
		System.out.println("C is: "+c);
		c = a*b;
		System.out.println("C is: "+c);
		c = a/b;
		System.out.println("C is: "+c);
		c = a%b;
		System.out.println("C is: "+c);
		
		//assignment operator
		c = a;
		System.out.println("C is: "+c);
		c += a;   	//c = c+a
		System.out.println("C is: "+c);
		c *= b;		// c = c*b
		System.out.println("C is: "+c);
		
		//Increment or Decrement
		System.out.println("Value of A : "+a);
		a++;
		System.out.println("Value of A : "+a);
		++a;
		System.out.println("Value of A : "+a);
		a++;
		System.out.println("Value of A : "+a);
		b--;
		System.out.println("Value of B : "+b);
		--b;
		System.out.println("Value of B : "+b);
		
		
		//Relational operators
		System.out.println(a==b);
		System.out.println(a>b);
		System.out.println(a>=b);
		System.out.println(a<b);
		System.out.println(a<=b);
		System.out.println(a!=b);
*/
		
		
	}

}
