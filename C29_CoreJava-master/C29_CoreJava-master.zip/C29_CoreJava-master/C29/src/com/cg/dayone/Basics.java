package com.cg.dayone;

public class Basics {

	public static void main(String[] args) {
		System.out.println("Hi Hello C29 Batch");
	}

}
