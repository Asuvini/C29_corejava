package com.cg.dayeight.interfaces;

public class InterfaceDemo {

	public static void main(String[] args) {
		ClassOne c = new ClassOne();
		
		c.print();
		c.show();
	}

}
