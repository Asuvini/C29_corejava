package com.cg.daytwo;

public class WhileLoop {

	public static void main(String[] args) {
		int a = 1;
		while(a<11) {
			System.out.println("Reventh K");
			a++;
		}

	}

}
