package com.cg.daytwo;

public class DoWhileLoop {

	public static void main(String[] args) {
		int a = 5;
		do {
			System.out.println("Reventh K");
			a++;
		}while(a>100);

	}

}
