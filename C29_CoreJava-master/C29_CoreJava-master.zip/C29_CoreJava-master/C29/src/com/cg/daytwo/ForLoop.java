package com.cg.daytwo;

public class ForLoop {

	public static void main(String[] args) {
		for(int i = 0; i < 5; i++) {
			System.out.println("Reventh K");
			//1. initialization
			//2. condition
			//3. Execute Code
			//4. Inc/Dec
		}
	}

}
