package com.cg.daythree.package2;

import com.cg.daythree.package1.Base;

public class Demo {

	public static void main(String[] args) {
		Base b = new Base();
		
		b.varPublic = 23;
		
		b.methodPublic();

	}

}
