package com.cg.daythree.encapsulation;

public class StudentDemo {

	public static void main(String[] args) {
		Student s = new Student();
		s.setName("Reventh");
		s.setRollno(1234);
		s.setAge(25);
		System.out.println(s);
	}

}
